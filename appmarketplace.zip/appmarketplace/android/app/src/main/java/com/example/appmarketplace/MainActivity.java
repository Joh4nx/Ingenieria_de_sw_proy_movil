package com.example.appmarketplace;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
