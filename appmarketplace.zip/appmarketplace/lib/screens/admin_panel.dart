import 'dart:convert';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;

////////////////////////////////////////
// Función para sanitizar el email    //
////////////////////////////////////////
String sanitizeEmail(String email) {
  return email.toLowerCase().replaceAll(RegExp(r'[@.]'), '_');
}

////////////////////////////////////////
// Función para generar chatRoomId      //
////////////////////////////////////////
String generateChatRoomId(String publicationId, String email1, String email2) {
  // Ordena los emails alfabéticamente para generar un ID consistente
  List<String> emails = [email1, email2];
  emails.sort();
  return '$publicationId#${sanitizeEmail(emails[0])}#${sanitizeEmail(emails[1])}';
}

////////////////////////////////////////
// EDIT PUBLICATION PAGE (Stub)       //
////////////////////////////////////////
class EditPublicationPage extends StatelessWidget {
  final Map<String, dynamic> publicationData;
  const EditPublicationPage({Key? key, required this.publicationData})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Aquí implementas el formulario para editar la publicación
    return Scaffold(
      appBar: AppBar(title: const Text("Editar Publicación")),
      body: Center(
        child: Text("Editar publicación: ${publicationData['title'] ?? ''}"),
      ),
    );
  }
}

////////////////////////////////////////
// ADMIN PUBLICATION DETAIL PAGE      //
////////////////////////////////////////
class AdminPublicationDetailPage extends StatelessWidget {
  final Map<String, dynamic> publicationData;
  const AdminPublicationDetailPage({Key? key, required this.publicationData})
      : super(key: key);

  Future<void> _deletePublication(BuildContext context, String publicationId) async {
    try {
      await FirebaseFirestore.instance
          .collection('publicaciones')
          .doc(publicationId)
          .delete();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Publicación eliminada correctamente")),
      );
      Navigator.pop(context); // Regresa a la pantalla anterior
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al eliminar publicación: $e")),
      );
    }
  }

  void _confirmDelete(BuildContext context, String publicationId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Eliminar publicación"),
        content: const Text("¿Estás seguro de que deseas eliminar esta publicación?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Cancelar"),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _deletePublication(context, publicationId);
            },
            child: const Text("Eliminar", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _contactPublisher(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;
    final currentUserEmail = currentUser.email!;
    final publicationId = publicationData['publicationId'] ?? '';
    final publisherEmail = publicationData['userEmail'] ?? 'Desconocido';
    final chatRoomId = generateChatRoomId(publicationId, currentUserEmail, publisherEmail);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatPage(
          chatRoomId: chatRoomId,
          publisherEmail: publisherEmail,
          publicationTitle: publicationData['title'] ?? '',
          publicationId: publicationId,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = publicationData['title'] ?? '';
    final description = publicationData['description'] ?? '';
    final price = publicationData['price'] != null
        ? "\$${publicationData['price'].toString()}"
        : '';
    final category = publicationData['category'] ?? '';
    final publisherEmail = publicationData['userEmail'] ?? 'Desconocido';
    final publicationId = publicationData['publicationId'] ?? '';
    final List<dynamic> images = publicationData['images'] ?? [];

    return Scaffold(
      appBar: AppBar(
        title: Text("Detalle: $title"),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () => _confirmDelete(context, publicationId),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (images.isNotEmpty)
              SizedBox(
                height: 300,
                child: PageView.builder(
                  itemCount: images.length,
                  itemBuilder: (context, index) {
                    try {
                      final imageBase64 = images[index] as String;
                      final bytes = base64Decode(imageBase64);
                      return Image.memory(bytes, fit: BoxFit.cover);
                    } catch (e) {
                      return Container(
                        color: Colors.grey,
                        child: const Center(
                          child: Icon(Icons.error, color: Colors.white),
                        ),
                      );
                    }
                  },
                ),
              )
            else
              Container(
                height: 300,
                color: Colors.grey[300],
                child: const Center(
                  child: Icon(Icons.image, size: 50, color: Colors.white),
                ),
              ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(category,
                      style: const TextStyle(
                          fontSize: 16, color: Colors.grey)),
                  const SizedBox(height: 8),
                  Text(price,
                      style: const TextStyle(
                          fontSize: 20, color: Colors.green)),
                  const SizedBox(height: 16),
                  Text(description,
                      style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 16),
                  Text('Publicado por: $publisherEmail',
                      style: const TextStyle(
                          fontSize: 16, color: Colors.blueGrey)),
                  const SizedBox(height: 24),
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: () => _contactPublisher(context),
                      icon: const Icon(Icons.message),
                      label: const Text('Contactar'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

////////////////////////////////////////
// ADMIN PUBLICATIONS PAGE            //
////////////////////////////////////////
class AdminPublicationsPage extends StatefulWidget {
  const AdminPublicationsPage({Key? key}) : super(key: key);

  @override
  State<AdminPublicationsPage> createState() => _AdminPublicationsPageState();
}

class _AdminPublicationsPageState extends State<AdminPublicationsPage> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.trim().toLowerCase();
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _deletePublication(String publicationId) async {
    try {
      await FirebaseFirestore.instance
          .collection('publicaciones')
          .doc(publicationId)
          .delete();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Publicación eliminada correctamente")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al eliminar publicación: $e")),
      );
    }
  }

  void _confirmDelete(String publicationId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Eliminar publicación"),
        content: const Text("¿Estás seguro de que deseas eliminar esta publicación?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Cancelar"),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _deletePublication(publicationId);
            },
            child: const Text("Eliminar", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Barra de búsqueda
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: TextField(
            controller: _searchController,
            decoration: const InputDecoration(
              hintText: 'Buscar publicaciones...',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
            ),
          ),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('publicaciones')
                .orderBy('createdAt', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return const Center(child: Text("No hay publicaciones."));
              }
              final docs = snapshot.data!.docs;
              final filteredDocs = docs.where((doc) {
                final data = doc.data() as Map<String, dynamic>;
                final title = data['title']?.toString().toLowerCase() ?? "";
                final description = data['description']?.toString().toLowerCase() ?? "";
                return title.contains(_searchQuery) || description.contains(_searchQuery);
              }).toList();
              // Agregar publicationId a cada documento.
              for (var doc in filteredDocs) {
                (doc.data() as Map<String, dynamic>)['publicationId'] = doc.id;
              }
              return GridView.builder(
                padding: const EdgeInsets.all(8.0),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 1,
                ),
                itemCount: filteredDocs.length,
                itemBuilder: (context, index) {
                  final data = filteredDocs[index].data() as Map<String, dynamic>;
                  final title = data['title'] ?? 'Sin título';
                  final price = data['price'] != null ? "\$${data['price'].toString()}" : "";
                  final List<dynamic> images = data['images'] ?? [];
                  Widget imageWidget;
                  if (images.isNotEmpty) {
                    try {
                      final imageBase64 = images[0] as String;
                      final bytes = base64Decode(imageBase64);
                      imageWidget = Image.memory(bytes, fit: BoxFit.cover);
                    } catch (e) {
                      imageWidget = Container(
                        color: Colors.grey,
                        child: const Icon(Icons.error, color: Colors.white),
                      );
                    }
                  } else {
                    imageWidget = Container(
                      color: Colors.grey[300],
                      child: const Center(child: Icon(Icons.image, size: 50, color: Colors.white)),
                    );
                  }
                  return Stack(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AdminPublicationDetailPage(publicationData: data),
                            ),
                          );
                        },
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12.0),
                            child: Stack(
                              children: [
                                Positioned.fill(child: imageWidget),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  child: Container(
                                    padding: const EdgeInsets.all(8.0),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                                      ),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          title,
                                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                        ),
                                        if (price.isNotEmpty)
                                          Text(
                                            price,
                                            style: const TextStyle(color: Colors.white, fontSize: 14),
                                            textAlign: TextAlign.center,
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        top: 4,
                        right: 4,
                        child: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () {
                            _confirmDelete(data['publicationId']);
                          },
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

////////////////////////////////////////
// ADMIN USERS PAGE                   //
////////////////////////////////////////
class AdminUsersPage extends StatefulWidget {
  const AdminUsersPage({Key? key}) : super(key: key);

  @override
  State<AdminUsersPage> createState() => _AdminUsersPageState();
}

class _AdminUsersPageState extends State<AdminUsersPage> {
  Future<void> _deleteUser(String userId) async {
    try {
      await FirebaseFirestore.instance.collection('usuarios').doc(userId).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Usuario eliminado correctamente")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al eliminar usuario: $e")),
      );
    }
  }

  void _confirmDelete(String userId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Eliminar usuario"),
        content: const Text("¿Estás seguro de que deseas eliminar este usuario?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Cancelar"),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _deleteUser(userId);
            },
            child: const Text("Eliminar", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Administrar Usuarios"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('usuarios').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No hay usuarios."));
          }
          final users = snapshot.data!.docs;
          return ListView.builder(
            itemCount: users.length,
            itemBuilder: (context, index) {
              final data = users[index].data() as Map<String, dynamic>;
              final displayName = data['displayName'] ?? "Sin nombre";
              final email = data['email'] ?? "Sin correo";
              final photo = data['photoURL'] ?? "";
              ImageProvider? imageProvider;
              if (photo.isNotEmpty) {
                if (photo.startsWith("http")) {
                  imageProvider = NetworkImage(photo);
                } else {
                  try {
                    imageProvider = MemoryImage(base64Decode(photo));
                  } catch (e) {
                    imageProvider = null;
                  }
                }
              }
              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: imageProvider,
                  child: imageProvider == null ? const Icon(Icons.person) : null,
                ),
                title: Text(displayName),
                subtitle: Text(email),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    _confirmDelete(users[index].id);
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

////////////////////////////////////////
// ANALISIS PAGE (Stub)               //
////////////////////////////////////////
class AnalisisPage extends StatelessWidget {
  const AnalisisPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          "Panel de Análisis",
          style: Theme.of(context).textTheme.headlineMedium,
        ),
      ),
    );
  }
}

////////////////////////////////////////
// PERFIL PAGE (Reutilizada)          //
////////////////////////////////////////
class PerfilPage extends StatefulWidget {
  const PerfilPage({Key? key}) : super(key: key);
  @override
  State<PerfilPage> createState() => _PerfilPageState();
}

class _PerfilPageState extends State<PerfilPage> {
  User? user = FirebaseAuth.instance.currentUser;

  Future<DocumentSnapshot<Map<String, dynamic>>> _getUserData() async {
    return FirebaseFirestore.instance.collection('usuarios').doc(user!.uid).get();
  }

  Widget _buildInfoItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(fontSize: 14, color: Colors.grey),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mi Perfil"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              future: _getUserData(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                Map<String, dynamic>? data = snapshot.hasData && snapshot.data!.exists
                    ? snapshot.data!.data()
                    : null;
                final displayName = data?['displayName'] ?? user?.displayName ?? "Usuario";
                final email = user?.email ?? "Correo no disponible";
                final photo = data?['photoURL'] ?? user?.photoURL;
                ImageProvider? imageProvider;
                if (photo != null && photo.isNotEmpty) {
                  if (photo.startsWith("http")) {
                    imageProvider = NetworkImage(photo);
                  } else {
                    try {
                      imageProvider = MemoryImage(base64Decode(photo));
                    } catch (e) {
                      imageProvider = null;
                    }
                  }
                }
                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.grey[300],
                        backgroundImage: imageProvider,
                        child: imageProvider == null ? const Icon(Icons.person, size: 50, color: Colors.white) : null,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        displayName,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        email,
                        style: const TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                      const SizedBox(height: 16),
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _buildInfoItem("Miembro desde", "01/01/2023"),
                              _buildInfoItem("Puntuación", "4.8"),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const EditProfilePage()),
                          );
                          setState(() {});
                        },
                        icon: const Icon(Icons.edit),
                        label: const Text("Editar perfil"),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            const Divider(thickness: 1),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: const [
                  Text(
                    "Mis Publicaciones",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('publicaciones')
                  .where('userId', isEqualTo: user?.uid)
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: Text("No tienes publicaciones.")),
                  );
                }
                final publications = snapshot.data!.docs;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: publications.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 1,
                    ),
                    itemBuilder: (context, index) {
                      final pubData = publications[index].data() as Map<String, dynamic>;
                      final title = pubData['title'] ?? 'Sin título';
                      final price = pubData['price'] != null ? "\$${pubData['price'].toString()}" : "";
                      final List<dynamic> images = pubData['images'] ?? [];
                      Widget imageWidget;
                      if (images.isNotEmpty) {
                        try {
                          final imageBase64 = images[0] as String;
                          final bytes = base64Decode(imageBase64);
                          imageWidget = Image.memory(bytes, fit: BoxFit.cover);
                        } catch (e) {
                          imageWidget = Container(
                            color: Colors.grey,
                            child: const Icon(Icons.error, color: Colors.white),
                          );
                        }
                      } else {
                        imageWidget = Container(
                          color: Colors.grey[300],
                          child: const Center(child: Icon(Icons.image, size: 50, color: Colors.white)),
                        );
                      }
                      return InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EditPublicationPage(publicationData: pubData),
                            ),
                          );
                        },
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12.0),
                            child: Stack(
                              children: [
                                Positioned.fill(child: imageWidget),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  child: Container(
                                    padding: const EdgeInsets.all(8.0),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                                      ),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(
                                          title,
                                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                        ),
                                        if (price.isNotEmpty)
                                          Text(
                                            price,
                                            style: const TextStyle(color: Colors.white, fontSize: 14),
                                            textAlign: TextAlign.center,
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

////////////////////////////////////////
// EDIT PROFILE PAGE                  //
////////////////////////////////////////
class EditProfilePage extends StatefulWidget {
  const EditProfilePage({Key? key}) : super(key: key);
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _displayNameController = TextEditingController();
  File? _imageFile;
  bool _isLoading = false;
  User? user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _displayNameController.text = user?.displayName ?? "";
  }

  @override
  void dispose() {
    _displayNameController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<String> _compressAndEncodeImage(File imageFile) async {
    final imageBytes = await imageFile.readAsBytes();
    final decodedImage = img.decodeImage(imageBytes);
    if (decodedImage == null) {
      throw Exception("Error al decodificar la imagen.");
    }
    final compressedImage = img.encodeJpg(decodedImage, quality: 50);
    return base64Encode(compressedImage);
  }

  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _isLoading = true;
    });
    try {
      final newDisplayName = _displayNameController.text.trim();
      await user?.updateDisplayName(newDisplayName);
      Map<String, dynamic> updateData = {
        'displayName': newDisplayName,
      };
      if (_imageFile != null) {
        final base64Image = await _compressAndEncodeImage(_imageFile!);
        updateData['photoURL'] = base64Image;
      }
      await FirebaseFirestore.instance
          .collection('usuarios')
          .doc(user!.uid)
          .set(updateData, SetOptions(merge: true));
      await user?.reload();
      user = FirebaseAuth.instance.currentUser;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Perfil actualizado correctamente")),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al actualizar perfil: $e")),
      );
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    String? currentPhoto = user?.photoURL;
    ImageProvider? profileImage;
    if (_imageFile != null) {
      profileImage = FileImage(_imageFile!);
    } else if (currentPhoto != null && currentPhoto.isNotEmpty) {
      if (currentPhoto.startsWith("http")) {
        profileImage = NetworkImage(currentPhoto);
      } else {
        try {
          profileImage = MemoryImage(base64Decode(currentPhoto));
        } catch (_) {
          profileImage = null;
        }
      }
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text("Editar Perfil"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : Form(
          key: _formKey,
          child: ListView(
            children: [
              Center(
                child: GestureDetector(
                  onTap: _pickImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: profileImage,
                    child: profileImage == null
                        ? const Icon(Icons.person, size: 50, color: Colors.white)
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _displayNameController,
                decoration: const InputDecoration(
                  labelText: "Nombre de usuario",
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "El nombre de usuario no puede estar vacío";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _updateProfile,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
                child: const Text("Guardar cambios"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

////////////////////////////////////////
// CHAT PAGE                          //
////////////////////////////////////////
class ChatPage extends StatefulWidget {
  final String chatRoomId;
  final String publisherEmail;
  final String publicationTitle;
  final String publicationId;
  const ChatPage({
    Key? key,
    required this.chatRoomId,
    required this.publisherEmail,
    required this.publicationTitle,
    required this.publicationId,
  }) : super(key: key);

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _createChatRoomIfNotExists();
    _resetUnreadCount();
  }

  Future<void> _createChatRoomIfNotExists() async {
    final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatRoomId);
    final snapshot = await chatRef.get();
    if (!snapshot.exists) {
      final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
      final publisherSanitized = sanitizeEmail(widget.publisherEmail);
      String publicationImage = "";
      final pubDoc = await FirebaseFirestore.instance
          .collection('publicaciones')
          .doc(widget.publicationId)
          .get();
      if (pubDoc.exists) {
        final pubData = pubDoc.data() as Map<String, dynamic>;
        final List<dynamic> images = pubData['images'] ?? [];
        if (images.isNotEmpty) {
          publicationImage = images[0] as String;
        }
      }
      await chatRef.set({
        'participants': [currentUserSanitized, publisherSanitized],
        'publicationTitle': widget.publicationTitle,
        'publicationId': widget.publicationId,
        'publicationImage': publicationImage,
        'unreadCounts': {currentUserSanitized: 0, publisherSanitized: 0},
        'lastMessage': '',
        'lastMessageTimestamp': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> _resetUnreadCount() async {
    final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
    await FirebaseFirestore.instance
        .collection('chats')
        .doc(widget.chatRoomId)
        .update({'unreadCounts.$currentUserSanitized': 0});
  }

  void _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;
    _messageController.clear();
    final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
    final recipientSanitized = sanitizeEmail(widget.publisherEmail);
    final messageData = {
      'sender': currentUserSanitized,
      'message': message,
      'timestamp': FieldValue.serverTimestamp(),
    };
    final chatRef = FirebaseFirestore.instance.collection('chats').doc(widget.chatRoomId);
    await chatRef.collection('messages').add(messageData);
    await chatRef.update({
      'lastMessage': message,
      'lastMessageTimestamp': FieldValue.serverTimestamp(),
      'unreadCounts.$recipientSanitized': FieldValue.increment(1),
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat con ${widget.publisherEmail}'),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  .doc(widget.chatRoomId)
                  .collection('messages')
                  .orderBy('timestamp', descending: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final messages = snapshot.data!.docs;
                return ListView.builder(
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final data = messages[index].data() as Map<String, dynamic>;
                    final sender = data['sender'] ?? 'Desconocido';
                    final message = data['message'] ?? '';
                    final isMe = sender == currentUserSanitized;
                    return Container(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isMe ? Colors.blueAccent : Colors.grey[300],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          message,
                          style: TextStyle(color: isMe ? Colors.white : Colors.black),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          const Divider(height: 1),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            color: Colors.grey[200],
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: 'Escribe un mensaje...',
                      border: InputBorder.none,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

////////////////////////////////////////
// ADMIN HOME PAGE                    //
////////////////////////////////////////
class AdminHomePage extends StatefulWidget {
  const AdminHomePage({Key? key}) : super(key: key);

  @override
  State<AdminHomePage> createState() => _AdminHomePageState();
}

class _AdminHomePageState extends State<AdminHomePage> {
  int _currentIndex = 0;
  // Las pantallas del panel de administración: Publicaciones, Usuarios, Chats, Análisis y Perfil.
  final List<Widget> _screens = const [
    AdminPublicationsPage(),
    AdminUsersPage(),
    AdminChatsPage(),
    AnalisisPage(),
    PerfilPage(),
  ];

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Panel de Administrador"),
        backgroundColor: Theme.of(context).colorScheme.primary,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: "Cerrar sesión",
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
        selectedItemColor: Theme.of(context).colorScheme.primary,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.article),
            label: 'Publicaciones',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people),
            label: 'Usuarios',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'Chats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.analytics),
            label: 'Análisis',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}

////////////////////////////////////////
// ADMIN CHATS PAGE                   //
////////////////////////////////////////
class AdminChatsPage extends StatefulWidget {
  const AdminChatsPage({Key? key}) : super(key: key);

  @override
  State<AdminChatsPage> createState() => _AdminChatsPageState();
}

class _AdminChatsPageState extends State<AdminChatsPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    final currentUserEmail = _auth.currentUser?.email;
    if (currentUserEmail == null) {
      return const Center(child: Text('No autenticado.'));
    }
    final sanitizedCurrentUser = sanitizeEmail(currentUserEmail);
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('chats')
          .where('participants', arrayContains: sanitizedCurrentUser)
          .orderBy('lastMessageTimestamp', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No hay conversaciones.'));
        }
        final chatDocs = snapshot.data!.docs;
        return ListView.builder(
          itemCount: chatDocs.length,
          itemBuilder: (context, index) {
            final data = chatDocs[index].data() as Map<String, dynamic>;
            final publicationTitle = data['publicationTitle'] ?? 'Publicación';
            final publicationId = data['publicationId'] ?? '';
            final lastMessage = data['lastMessage'] ?? '';
            final participants = List<String>.from(data['participants'] ?? []);
            // En este caso usamos el ID del documento de chat (chatDocs[index].id)
            final chatRoomId = chatDocs[index].id;
            final otherEmail = participants.firstWhere((email) => email != sanitizedCurrentUser, orElse: () => 'Desconocido');
            final unreadCounts = (data['unreadCounts'] as Map<String, dynamic>?) ?? {};
            final unreadCount = (unreadCounts[sanitizedCurrentUser] ?? 0) as int;
            return ListTile(
              title: Text(publicationTitle),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Chat con: $otherEmail'),
                  Text(
                    lastMessage,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontStyle: FontStyle.italic),
                  ),
                ],
              ),
              trailing: unreadCount > 0
                  ? CircleAvatar(
                backgroundColor: Colors.red,
                radius: 12,
                child: Text(
                  unreadCount.toString(),
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              )
                  : null,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatPage(
                      chatRoomId: chatRoomId,
                      publisherEmail: data['userEmail'] ?? 'Desconocido',
                      publicationTitle: publicationTitle,
                      publicationId: publicationId,
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

