import 'dart:io';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'edit_publication_page.dart';

/// Widget reutilizable para mostrar imágenes codificadas en Base64.
/// Si ocurre algún error o no hay imagen, se muestra un placeholder profesional.
class Base64ImageWidget extends StatelessWidget {
  final String? base64String;
  final BoxFit fit;
  final double? width;
  final double? height;
  final Widget? placeholder;

  const Base64ImageWidget({
    Key? key,
    required this.base64String,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.placeholder,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (base64String == null || base64String!.isEmpty) {
      return placeholder ??
          Container(
            width: width,
            height: height,
            color: Colors.grey[300],
            child: const Center(
              child: Icon(Icons.image, size: 50, color: Colors.white),
            ),
          );
    }
    try {
      final bytes = base64Decode(base64String!);
      return Image.memory(bytes, fit: fit, width: width, height: height);
    } catch (e) {
      return placeholder ??
          Container(
            width: width,
            height: height,
            color: Colors.grey,
            child: const Center(
              child: Icon(Icons.error, size: 50, color: Colors.white),
            ),
          );
    }
  }
}

/// Función para "sanitizar" el email (reemplaza "@" y "." por guion bajo)
String sanitizeEmail(String email) {
  return email.toLowerCase().replaceAll(RegExp(r'[@.]'), '_');
}

/// ============================================================
/// HOME PAGE CON TABS: Inicio, Mensajes, Mi Perfil
/// ============================================================
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  final List<Widget> _screens = const [
    InicioPage(),
    MensajesPage(),
    PerfilPage(),
  ];

  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Marketplace'),
        backgroundColor: Theme.of(context).primaryColor,
        actions: [
          if (_currentIndex == 0)
            IconButton(
              icon: const Icon(Icons.add),
              tooltip: 'Publicar',
              onPressed: () {
                Navigator.pushNamed(context, '/publicar');
              },
            ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Cerrar sesión',
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped,
        elevation: 8,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Inicio'),
          BottomNavigationBarItem(icon: Icon(Icons.message), label: 'Mensajes'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Mi Perfil'),
        ],
      ),
    );
  }
}

/// ============================================================
/// INICIO PAGE: Barra de búsqueda, filtros y GridView de publicaciones
/// ============================================================
class InicioPage extends StatefulWidget {
  const InicioPage({Key? key}) : super(key: key);
  @override
  State<InicioPage> createState() => _InicioPageState();
}
class _InicioPageState extends State<InicioPage> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  // Filtros adicionales
  String _selectedCategoryFilter = 'Todas';
  String _selectedPriceFilter = 'Todos';
  final List<String> _categoryOptions = [
    'Todas',
    'Electrónica',
    'Muebles',
    'Ropa',
    'Vehículos',
    'Inmuebles',
    'Otros',
  ];
  final List<String> _priceOptions = [
    'Todos',
    '0-50',
    '50-100',
    '100-200',
    '>200',
  ];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.trim().toLowerCase();
      });
    });
  }
  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
  bool _priceInRange(num price) {
    switch (_selectedPriceFilter) {
      case '0-50': return price >= 0 && price <= 50;
      case '50-100': return price > 50 && price <= 100;
      case '100-200': return price > 100 && price <= 200;
      case '>200': return price > 200;
      default: return true;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Barra de búsqueda y botón publicar.
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
          child: Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  child: TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      hintText: 'Buscar publicaciones...',
                      prefixIcon: Icon(Icons.search),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 15.0),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12.0),
              Material(
                shape: const CircleBorder(),
                color: Theme.of(context).primaryColor,
                child: IconButton(
                  icon: const Icon(Icons.add, color: Colors.white, size: 28),
                  tooltip: 'Publicar',
                  onPressed: () {
                    Navigator.pushNamed(context, '/publicar');
                  },
                ),
              ),
            ],
          ),
        ),
        // Filtros: Dropdown de categoría y precio.
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _selectedCategoryFilter,
                  decoration: const InputDecoration(
                    labelText: 'Categoría',
                    border: OutlineInputBorder(),
                  ),
                  items: _categoryOptions
                      .map((cat) => DropdownMenuItem<String>(
                      value: cat, child: Text(cat)))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedCategoryFilter = value!;
                    });
                  },
                ),
              ),
              const SizedBox(width: 16.0),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: _selectedPriceFilter,
                  decoration: const InputDecoration(
                    labelText: 'Precio',
                    border: OutlineInputBorder(),
                  ),
                  items: _priceOptions
                      .map((range) => DropdownMenuItem<String>(
                      value: range, child: Text(range)))
                      .toList(),
                  onChanged: (value) {
                    setState(() {
                      _selectedPriceFilter = value!;
                    });
                  },
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12.0),
        // GridView de publicaciones.
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('publicaciones')
                .orderBy('createdAt', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return const Center(child: Text('No hay publicaciones.'));
              }
              final docs = snapshot.data!.docs;
              final filteredDocs = docs.where((doc) {
                final data = doc.data() as Map<String, dynamic>;
                final title = data['title']?.toString().toLowerCase() ?? "";
                final description = data['description']?.toString().toLowerCase() ?? "";
                final category = data['category']?.toString().toLowerCase() ?? "";
                final price = data['price'] is num ? data['price'] as num : 0;
                final matchesSearch = title.contains(_searchQuery) || description.contains(_searchQuery);
                final matchesCategory = _selectedCategoryFilter == 'Todas' ||
                    category == _selectedCategoryFilter.toLowerCase();
                final matchesPrice = _priceInRange(price);
                return matchesSearch && matchesCategory && matchesPrice;
              }).toList();
              // Agrega el publicationId a cada documento.
              for (var doc in filteredDocs) {
                (doc.data() as Map<String, dynamic>)['publicationId'] = doc.id;
              }
              return GridView.builder(
                padding: const EdgeInsets.all(12.0),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1,
                ),
                itemCount: filteredDocs.length,
                itemBuilder: (context, index) {
                  final data = filteredDocs[index].data() as Map<String, dynamic>;
                  final title = data['title'] ?? 'Sin título';
                  final price = data['price'] != null ? "\$${data['price'].toString()}" : "";
                  final List<dynamic> images = data['images'] ?? [];
                  Widget imageWidget;
                  if (images.isNotEmpty) {
                    imageWidget = Base64ImageWidget(
                      base64String: images[0] as String,
                      placeholder: Container(
                        color: Colors.grey[300],
                        child: const Center(
                          child: Icon(Icons.image, size: 50, color: Colors.white),
                        ),
                      ),
                    );
                  } else {
                    imageWidget = Base64ImageWidget(
                      base64String: "",
                      placeholder: Container(
                        color: Colors.grey[300],
                        child: const Center(
                          child: Icon(Icons.image, size: 50, color: Colors.white),
                        ),
                      ),
                    );
                  }
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PublicationDetailPage(data: data),
                        ),
                      );
                    },
                    child: Card(
                      elevation: 4,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16.0)),
                      clipBehavior: Clip.antiAlias,
                      child: Stack(
                        children: [
                          Positioned.fill(child: imageWidget),
                          Positioned(
                            left: 0,
                            right: 0,
                            bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.all(8.0),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Colors.transparent,
                                    Colors.black.withOpacity(0.7)
                                  ],
                                ),
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    title,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    textAlign: TextAlign.center,
                                  ),
                                  if (price.isNotEmpty)
                                    Text(
                                      price,
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 14),
                                      textAlign: TextAlign.center,
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

/// ============================================================
/// MENSAJES PAGE: Lista de salas de chat (cada chat es único por publicación)
/// ============================================================
class MensajesPage extends StatefulWidget {
  const MensajesPage({Key? key}) : super(key: key);
  @override
  State<MensajesPage> createState() => _MensajesPageState();
}
class _MensajesPageState extends State<MensajesPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    final currentUserEmail = _auth.currentUser?.email;
    if (currentUserEmail == null) {
      return const Center(child: Text('No autenticado.'));
    }
    final sanitizedCurrentUser = sanitizeEmail(currentUserEmail);
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('chats')
          .where('participants', arrayContains: sanitizedCurrentUser)
          .orderBy('lastMessageTimestamp', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Center(child: Text('No hay conversaciones.'));
        }
        final chatDocs = snapshot.data!.docs;
        return ListView.builder(
          itemCount: chatDocs.length,
          itemBuilder: (context, index) {
            final data = chatDocs[index].data() as Map<String, dynamic>;
            final publicationTitle = data['publicationTitle'] ?? 'Publicación';
            final publicationId = data['publicationId'] ?? '';
            final lastMessage = data['lastMessage'] ?? '';
            final participants = List<String>.from(data['participants'] ?? []);
            final otherEmail = participants.firstWhere((email) => email != sanitizedCurrentUser, orElse: () => 'Desconocido');
            final unreadCounts = (data['unreadCounts'] as Map<String, dynamic>?) ?? {};
            final unreadCount = (unreadCounts[sanitizedCurrentUser] ?? 0) as int;
            final publicationImageBase64 = data['publicationImage'] as String? ?? "";
            return ListTile(
              leading: Base64ImageWidget(
                base64String: publicationImageBase64,
                width: 40,
                height: 40,
                placeholder: const CircleAvatar(child: Icon(Icons.article, size: 20)),
              ),
              title: Text(publicationTitle),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Chat con: $otherEmail'),
                  Text(
                    lastMessage,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontStyle: FontStyle.italic),
                  ),
                ],
              ),
              trailing: unreadCount > 0
                  ? CircleAvatar(
                backgroundColor: Colors.red,
                radius: 12,
                child: Text(
                  unreadCount.toString(),
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              )
                  : null,
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatPage(
                      chatRoomId: chatDocs[index].id,
                      publisherEmail: otherEmail,
                      publicationTitle: publicationTitle,
                      publicationId: publicationId,
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

/// ============================================================
/// PERFIL PAGE: Información del usuario (Mejorado para Marketplace)
/// ============================================================
class PerfilPage extends StatefulWidget {
  const PerfilPage({Key? key}) : super(key: key);
  @override
  State<PerfilPage> createState() => _PerfilPageState();
}
class _PerfilPageState extends State<PerfilPage> {
  User? user = FirebaseAuth.instance.currentUser;

  // Obtiene la información del usuario desde Firestore.
  Future<DocumentSnapshot<Map<String, dynamic>>> _getUserData() async {
    return FirebaseFirestore.instance.collection('usuarios').doc(user!.uid).get();
  }

  Widget _buildInfoItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(fontSize: 14, color: Colors.grey),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mi Perfil"),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Sección de información del perfil.
            FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              future: _getUserData(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                // Si el documento no existe, se usa la info de FirebaseAuth.
                Map<String, dynamic>? data = snapshot.hasData && snapshot.data!.exists
                    ? snapshot.data!.data()
                    : null;
                final displayName = data?['displayName'] ?? user?.displayName ?? "Usuario";
                final email = user?.email ?? "Correo no disponible";
                final photo = data?['photoURL'] ?? user?.photoURL;
                ImageProvider? imageProvider;
                if (photo != null && photo.isNotEmpty) {
                  if (photo.startsWith("http")) {
                    imageProvider = NetworkImage(photo);
                  } else {
                    try {
                      imageProvider = MemoryImage(base64Decode(photo));
                    } catch (e) {
                      imageProvider = null;
                    }
                  }
                }
                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      // Avatar con imagen o placeholder.
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.grey[300],
                        backgroundImage: imageProvider,
                        child: imageProvider == null
                            ? const Icon(Icons.person, size: 50, color: Colors.white)
                            : null,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        displayName,
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        email,
                        style: const TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                      const SizedBox(height: 16),
                      Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _buildInfoItem("Miembro desde", "01/01/2023"),
                              _buildInfoItem("Puntuación", "4.8"),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: () async {
                          // Navega a la pantalla de edición y al volver refresca la vista.
                          await Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const EditProfilePage()),
                          );
                          setState(() {});
                        },
                        icon: const Icon(Icons.edit),
                        label: const Text("Editar perfil"),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            const Divider(thickness: 1),
            // Sección de "Mis Publicaciones"
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: const [
                  Text(
                    "Mis Publicaciones",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('publicaciones')
                  .where('userId', isEqualTo: user?.uid)
                  .orderBy('createdAt', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Center(child: Text("No tienes publicaciones.")),
                  );
                }
                final publications = snapshot.data!.docs;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: publications.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1,
                    ),
                    itemBuilder: (context, index) {
                      final pubData = publications[index].data() as Map<String, dynamic>;
                      final title = pubData['title'] ?? 'Sin título';
                      final price = pubData['price'] != null
                          ? "\$${pubData['price'].toString()}"
                          : "";
                      final List<dynamic> images = pubData['images'] ?? [];
                      Widget imageWidget;
                      if (images.isNotEmpty) {
                        imageWidget = Base64ImageWidget(
                          base64String: images[0] as String,
                          placeholder: Container(
                            color: Colors.grey[300],
                            child: const Center(
                                child: Icon(Icons.image, size: 50, color: Colors.white)),
                          ),
                        );
                      } else {
                        imageWidget = Base64ImageWidget(
                          base64String: "",
                          placeholder: Container(
                            color: Colors.grey[300],
                            child: const Center(
                                child: Icon(Icons.image, size: 50, color: Colors.white)),
                          ),
                        );
                      }
                      return InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EditPublicationPage(publicationData: pubData),
                            ),
                          );
                        },
                        child: Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16.0)),
                          clipBehavior: Clip.antiAlias,
                          child: Stack(
                            children: [
                              Positioned.fill(child: imageWidget),
                              Positioned(
                                left: 0,
                                right: 0,
                                bottom: 0,
                                child: Container(
                                  padding: const EdgeInsets.all(8.0),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Colors.transparent,
                                        Colors.black.withOpacity(0.7)
                                      ],
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        title,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.center,
                                      ),
                                      if (price.isNotEmpty)
                                        Text(
                                          price,
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 14),
                                          textAlign: TextAlign.center,
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

/// ============================================================
/// EDIT PROFILE PAGE: Pantalla para editar el perfil del usuario
/// ============================================================
class EditProfilePage extends StatefulWidget {
  const EditProfilePage({Key? key}) : super(key: key);
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}
class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _displayNameController = TextEditingController();
  File? _imageFile;
  bool _isLoading = false;
  User? user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _displayNameController.text = user?.displayName ?? "";
  }

  @override
  void dispose() {
    _displayNameController.dispose();
    super.dispose();
  }

  /// Abre la galería para seleccionar una imagen.
  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile =
    await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  /// Comprime la imagen a calidad 50 y la codifica en base64.
  Future<String> _compressAndEncodeImage(File imageFile) async {
    final imageBytes = await imageFile.readAsBytes();
    final decodedImage = img.decodeImage(imageBytes);
    if (decodedImage == null) {
      throw Exception("Error al decodificar la imagen.");
    }
    final compressedImage = img.encodeJpg(decodedImage, quality: 50);
    return base64Encode(compressedImage);
  }

  /// Actualiza el perfil en FirebaseAuth (nombre) y en la colección "usuarios".
  Future<void> _updateProfile() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _isLoading = true;
    });
    try {
      final newDisplayName = _displayNameController.text.trim();
      // Actualiza el nombre en FirebaseAuth.
      await user?.updateDisplayName(newDisplayName);

      Map<String, dynamic> updateData = {
        'displayName': newDisplayName,
      };

      // Si se seleccionó una imagen, la comprime y la guarda en el campo "photoURL".
      if (_imageFile != null) {
        final base64Image = await _compressAndEncodeImage(_imageFile!);
        updateData['photoURL'] = base64Image;
      }

      // Actualiza (o crea) el documento en la colección "usuarios".
      await FirebaseFirestore.instance
          .collection('usuarios')
          .doc(user!.uid)
          .set(updateData, SetOptions(merge: true));

      await user?.reload();
      user = FirebaseAuth.instance.currentUser;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Perfil actualizado correctamente")),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error al actualizar perfil: $e")),
      );
    }
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Para mostrar la imagen: si se seleccionó una nueva, se usa FileImage;
    // de lo contrario, se evalúa el valor actual de user?.photoURL.
    String? currentPhoto = user?.photoURL;
    ImageProvider? profileImage;
    if (_imageFile != null) {
      profileImage = FileImage(_imageFile!);
    } else if (currentPhoto != null && currentPhoto.isNotEmpty) {
      if (currentPhoto.startsWith("http")) {
        profileImage = NetworkImage(currentPhoto);
      } else {
        try {
          profileImage = MemoryImage(base64Decode(currentPhoto));
        } catch (_) {
          profileImage = null;
        }
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Editar Perfil"),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : Form(
          key: _formKey,
          child: ListView(
            children: [
              Center(
                child: GestureDetector(
                  onTap: _pickImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: profileImage,
                    child: profileImage == null
                        ? const Icon(Icons.person,
                        size: 50, color: Colors.white)
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _displayNameController,
                decoration: const InputDecoration(
                  labelText: "Nombre de usuario",
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "El nombre de usuario no puede estar vacío";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _updateProfile,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12),
                ),
                child: const Text("Guardar cambios"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// ============================================================
/// PUBLICATION DETAIL PAGE: Detalles de la publicación e iniciar chat
/// ============================================================
class PublicationDetailPage extends StatelessWidget {
  final Map<String, dynamic> data;
  const PublicationDetailPage({Key? key, required this.data}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final title = data['title'] ?? '';
    final description = data['description'] ?? '';
    final price = data['price'] != null ? "\$${data['price'].toString()}" : '';
    final category = data['category'] ?? '';
    final publisherEmail = data['userEmail'] ?? 'Desconocido';
    final publicationId = data['publicationId'] ?? ''; // Agregado en InicioPage.
    final List<dynamic> images = data['images'] ?? [];
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (images.isNotEmpty)
              SizedBox(
                height: 300,
                child: PageView.builder(
                  itemCount: images.length,
                  itemBuilder: (context, index) {
                    return Base64ImageWidget(
                      base64String: images[index] as String,
                      fit: BoxFit.cover,
                    );
                  },
                ),
              )
            else
              Container(
                height: 300,
                color: Colors.grey[300],
                child: const Center(child: Icon(Icons.image, size: 50, color: Colors.white)),
              ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(category, style: const TextStyle(fontSize: 16, color: Colors.grey)),
                  const SizedBox(height: 8),
                  Text(price, style: const TextStyle(fontSize: 20, color: Colors.green)),
                  const SizedBox(height: 16),
                  Text(description, style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 16),
                  Text('Publicado por: $publisherEmail', style: const TextStyle(fontSize: 16, color: Colors.blueGrey)),
                  const SizedBox(height: 24),
                  Center(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        final currentUserEmail = FirebaseAuth.instance.currentUser!.email!;
                        final chatRoomId = _generateChatRoomId(publicationId, currentUserEmail, publisherEmail);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ChatPage(
                              chatRoomId: chatRoomId,
                              publisherEmail: publisherEmail,
                              publicationTitle: title,
                              publicationId: publicationId,
                            ),
                          ),
                        );
                      },
                      icon: const Icon(Icons.message),
                      label: const Text('Enviar mensaje'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  String _generateChatRoomId(String publicationId, String email1, String email2) {
    // Usamos '#' como separador para garantizar la unicidad según la publicación.
    return '$publicationId#${sanitizeEmail(email1)}#${sanitizeEmail(email2)}';
  }
}

/// ============================================================
/// CHAT PAGE: Pantalla para chatear (chat único por publicación)
/// ============================================================
class ChatPage extends StatefulWidget {
  final String chatRoomId;
  final String publisherEmail;
  final String publicationTitle;
  final String publicationId;

  const ChatPage({
    Key? key,
    required this.chatRoomId,
    required this.publisherEmail,
    required this.publicationTitle,
    required this.publicationId,
  }) : super(key: key);

  @override
  State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String? productImageBase64;

  // Fotos de perfil: para el usuario actual y para el publicador.
  String? currentUserPhoto;
  String? publisherPhoto;

  @override
  void initState() {
    super.initState();
    _createChatRoomIfNotExists();
    _resetUnreadCount();
    _loadProductImage();
    _loadProfilePhotos();
  }

  /// Carga la imagen del producto desde la publicación.
  Future<void> _loadProductImage() async {
    final doc = await FirebaseFirestore.instance
        .collection('publicaciones')
        .doc(widget.publicationId)
        .get();
    if (doc.exists) {
      final data = doc.data() as Map<String, dynamic>;
      final List<dynamic>? images = data['images'];
      if (images != null && images.isNotEmpty) {
        setState(() {
          productImageBase64 = images[0] as String;
        });
      }
    }
  }

  /// Carga las fotos de perfil tanto del usuario actual (desde FirebaseAuth) como del publicador (desde Firestore).
  Future<void> _loadProfilePhotos() async {
    final currentUser = _auth.currentUser;
    if (currentUser != null) {
      setState(() {
        currentUserPhoto = currentUser.photoURL;
      });
    }
    final querySnapshot = await FirebaseFirestore.instance
        .collection('usuarios')
        .where('email', isEqualTo: widget.publisherEmail)
        .limit(1)
        .get();
    if (querySnapshot.docs.isNotEmpty) {
      final data = querySnapshot.docs.first.data();
      setState(() {
        publisherPhoto = data['photoURL'] as String?;
      });
    }
  }

  /// Crea la sala de chat si no existe.
  Future<void> _createChatRoomIfNotExists() async {
    final chatRef =
    FirebaseFirestore.instance.collection('chats').doc(widget.chatRoomId);
    final snapshot = await chatRef.get();
    if (!snapshot.exists) {
      final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
      final publisherSanitized = sanitizeEmail(widget.publisherEmail);
      String publicationImage = "";
      final pubDoc = await FirebaseFirestore.instance
          .collection('publicaciones')
          .doc(widget.publicationId)
          .get();
      if (pubDoc.exists) {
        final pubData = pubDoc.data() as Map<String, dynamic>;
        final List<dynamic> images = pubData['images'] ?? [];
        if (images.isNotEmpty) {
          publicationImage = images[0] as String;
        }
      }
      await chatRef.set({
        'participants': [currentUserSanitized, publisherSanitized],
        'publicationTitle': widget.publicationTitle,
        'publicationId': widget.publicationId,
        'publicationImage': publicationImage,
        'unreadCounts': {currentUserSanitized: 0, publisherSanitized: 0},
        'lastMessage': '',
        'lastMessageTimestamp': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }

  /// Resetea el contador de mensajes no leídos para el usuario actual.
  Future<void> _resetUnreadCount() async {
    final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
    await FirebaseFirestore.instance
        .collection('chats')
        .doc(widget.chatRoomId)
        .update({'unreadCounts.$currentUserSanitized': 0});
  }

  /// Envía un mensaje y actualiza el último mensaje.
  void _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;
    _messageController.clear();
    final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
    final recipientSanitized = sanitizeEmail(widget.publisherEmail);
    final messageData = {
      'sender': currentUserSanitized,
      'message': message,
      'timestamp': FieldValue.serverTimestamp(),
    };
    final chatRef =
    FirebaseFirestore.instance.collection('chats').doc(widget.chatRoomId);
    await chatRef.collection('messages').add(messageData);
    await chatRef.update({
      'lastMessage': message,
      'lastMessageTimestamp': FieldValue.serverTimestamp(),
      'unreadCounts.$recipientSanitized': FieldValue.increment(1),
    });
  }

  /// Construye el header que muestra la imagen y el título del producto.
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).primaryColor.withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 2),
          )
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: productImageBase64 != null
                  ? DecorationImage(
                image: MemoryImage(
                  base64Decode(base64.normalize(productImageBase64!)),
                ),
                fit: BoxFit.cover,
              )
                  : null,
              color: Colors.grey.shade400,
            ),
            child: productImageBase64 == null
                ? const Icon(Icons.image, size: 40, color: Colors.white)
                : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              widget.publicationTitle,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Construye el avatar del usuario usando la foto de perfil almacenada.
  Widget _buildAvatar(String email) {
    String? photo;
    final currentUserEmail = _auth.currentUser!.email!;
    if (email == currentUserEmail) {
      photo = currentUserPhoto;
    } else {
      photo = publisherPhoto;
    }
    if (photo != null && photo.isNotEmpty) {
      if (photo.startsWith("http")) {
        return CircleAvatar(
          radius: 20,
          backgroundImage: NetworkImage(photo),
        );
      } else {
        try {
          final normalized = base64.normalize(photo.trim());
          return CircleAvatar(
            radius: 20,
            backgroundImage: MemoryImage(base64Decode(normalized)),
          );
        } catch (e) {
          return CircleAvatar(
            radius: 20,
            backgroundColor: Colors.grey,
            child: Text(
              email.isNotEmpty ? email[0].toUpperCase() : '?',
              style: const TextStyle(fontSize: 16, color: Colors.white),
            ),
          );
        }
      }
    } else {
      return CircleAvatar(
        radius: 20,
        backgroundColor: Colors.grey,
        child: Text(
          email.isNotEmpty ? email[0].toUpperCase() : '?',
          style: const TextStyle(fontSize: 16, color: Colors.white),
        ),
      );
    }
  }

  /// Construye una burbuja de chat con diseño moderno.
  /// Muestra el avatar solo en el último mensaje consecutivo de cada emisor.
  Widget _buildChatBubble(String sender, String message, bool isMe, bool showAvatar) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
      children: [
        if (!isMe && showAvatar) ...[
          _buildAvatar(sender),
          const SizedBox(width: 8),
        ],
        Flexible(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: isMe ? Theme.of(context).primaryColor : Colors.grey.shade300,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(20),
                topRight: const Radius.circular(20),
                bottomLeft: isMe ? const Radius.circular(20) : Radius.zero,
                bottomRight: isMe ? Radius.zero : const Radius.circular(20),
              ),
            ),
            child: Text(
              message,
              style: TextStyle(
                color: isMe ? Colors.white : Colors.black87,
                fontSize: 16,
              ),
            ),
          ),
        ),
        if (isMe && showAvatar) ...[
          const SizedBox(width: 8),
          _buildAvatar(sender),
        ],
      ],
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentUserSanitized = sanitizeEmail(_auth.currentUser!.email!);
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat con ${widget.publisherEmail}'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Column(
        children: [
          // Header: muestra la imagen y el título del producto.
          _buildHeader(),
          const Divider(height: 1),
          // Lista de mensajes.
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  .doc(widget.chatRoomId)
                  .collection('messages')
                  .orderBy('timestamp', descending: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final messages = snapshot.data!.docs;
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final currentData = messages[index].data() as Map<String, dynamic>;
                    final sender = currentData['sender'] ?? 'Desconocido';
                    final message = currentData['message'] ?? '';
                    final isMe = sender == currentUserSanitized;
                    bool showAvatar = false;
                    if (index == messages.length - 1) {
                      showAvatar = true;
                    } else {
                      final nextData = messages[index + 1].data() as Map<String, dynamic>;
                      if (nextData['sender'] != sender) {
                        showAvatar = true;
                      }
                    }
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: _buildChatBubble(sender, message, isMe, showAvatar),
                    );
                  },
                );
              },
            ),
          ),
          const Divider(height: 1),
          // Campo para escribir nuevos mensajes.
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: 'Escribe un mensaje...',
                      border: InputBorder.none,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.white),
                  onPressed: _sendMessage,
                  color: Theme.of(context).primaryColor,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
